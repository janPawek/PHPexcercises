<?php
echo "<pre>";
print_r($_POST);
echo "</pre>";

$firstName = $_GET['firstname'];
$lastName = $_GET['lastname'];
$age = $_GET['age'];

?>
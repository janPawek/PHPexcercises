<?php

$hostName = "localhost";
$userName = "root";
$password = "";
$dbName = "login";

$conn = mysqli_connect($hostName, $userName, $password, $dbName);
